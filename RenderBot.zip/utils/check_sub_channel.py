def check_channel():
    return True
