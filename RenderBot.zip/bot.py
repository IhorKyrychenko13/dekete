import threading
import time
import requests
from utils.check_sub_channel import check_channel

def keep_awake():
    while True:
        try:
            requests.get("https://your-app-name.onrender.com/")
        except:
            pass
        time.sleep(300)

threading.Thread(target=keep_awake, daemon=True).start()

# Тут основной код бота
if __name__ == "__main__":
    print("Bot is running...")
    # Запуск твоего бота здесь
